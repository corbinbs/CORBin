
import org.omg.CORBA.*;

public class passlong_client {

   public static void main(String args[]) {

	try {
	      //create and init ORB
	      ORB orb = ORB.init(args,null);
	
		


	 } catch (Exception e) {

		System.err.println("ERROR: " + e);
		e.printStackTrace(System.out);

	 }	
	      
   }

}
