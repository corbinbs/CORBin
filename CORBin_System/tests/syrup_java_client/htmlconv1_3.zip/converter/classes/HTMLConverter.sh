#!/usr/bin/sh
echo You are about to start the HTML Converter ...
echo
echo Have fun..
java -classpath $CLASSPATH:./ HTMLConverter
