/***************************CORBin-lib*********************************/
/* CORBin_base.c
 *
 * Some useful user-level C functions.
 * Declared and registered on the C side by cutil-CORBin.h
 */
#include <orb/orbit.h>
#include <string.h>

CORBA_Environment ev;
CORBA_ORB orb;

int CORBin_exception_init(char * str)
{
    printf("CORBin_exception_init:\n");

    CORBA_exception_init(&ev);

    printf("leaving CORBin_exception_init\n");
    return 0;
}

int CORBin_orb_init(char * str)
{
    int argc=3;
    char * argv[3];

    printf("CORBin_orb_init: \n");

    argv[0] = (char *) malloc(strlen("./CORBinTest") + 1);
    argv[1] = (char *) malloc(strlen("param1") +1 );
    argv[2] = (char *) malloc(strlen("param2") +1);

    printf("after malloc\n");

    strcpy(argv[0], "./CORBinTest");
    strcpy(argv[1], "param1");
    strcpy(argv[2], "param2");

    printf("after strcpy\n");

    printf("CORBin_orb_init: \n");

    orb = CORBA_ORB_init(&argc, argv, "orbit-local-orb",&ev); 

    if(!orb) 
	printf("orb IS NULL!\n");
    else 
	printf("orb is not null!\n");

    printf("leaving CORBin_orb_init\n");
    return 187;
}

CORBA_Object CORBin_string_to_object(char * str) 
{

    CORBA_Object x;


    printf("CORBin_string_to_object:  %s\n", str);
    
    x = CORBA_ORB_string_to_object(orb, str, &ev);


    if(!x) 
	printf("x IS NULL!\n");
    else 
	printf("x is not null!\n");

   printf("leaving CORBin_string_to_object\n");

   return x;
}

int CORBin_Object_release(CORBA_Object obj)
{

   CORBA_Object_release(obj, &ev);


   return 0;

}

