
/***********************************************************************
 *****Main CORBin-lib file.
 *****
 *****Simply used to include files that make up the library.
 *****When corbin-idl creates new C ORB interface files, they 
 *****are included here.
 ***********************************************************************/


 /******This pulls in the main CORBin functionality************/
 #include "CORBin_base.c"


 /******Code pulled in by corbin-idl***************************/


