/* 
 * name.h - header file to use name.c
 */

#include "CORBin_CosNaming.h"

CosNaming_Name* create_name(const char* name);

