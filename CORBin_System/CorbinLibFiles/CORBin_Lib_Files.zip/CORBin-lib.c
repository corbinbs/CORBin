
/***********************************************************************
 *****Main CORBin-lib file.
 *****
 *****Simply used to include files that make up the library.
 *****When corbin-idl creates new C ORB interface files, they 
 *****are included here.
 ***********************************************************************/

/***********test code **************/

int (*ML_entry)(int);  /*store ML function*/


void callmeback(int (*f)(int)) {

	int i, j;


	ML_entry = f;


	i = 45;

	printf("callmeback: i = %d\n", i);
	j = f(i);
	printf("callmeback: j = %d\n", j);


	printf("callmeback: i = %d\n", i);
	j = ML_entry(i);
	printf("callmeback: j = %d\n", j);

}

/**********end test******************/



 /******This pulls in the main CORBin functionality************/
 #include "CORBin_base.c"


 /******Code pulled in by corbin-idl***************************/


#include "/home/corbinbs/masters_proj/CORBin/corbin_idl_output/CORBin_Syrup.c"

#ifndef CORB_CODE_Syrup
#define CORB_CODE_Syrup

  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-stubs.c"
  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-common.c"

  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-skels.c"

#endif

#include "/home/corbinbs/masters_proj/CORBin/corbin_idl_output/CORBin_Syrup.c"

#ifndef CORB_CODE_Syrup
#define CORB_CODE_Syrup

  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-stubs.c"
  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-common.c"

  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-skels.c"

#endif

#include "/home/corbinbs/masters_proj/CORBin/corbin_idl_output/CORBin_Syrup.c"

#ifndef CORB_CODE_Syrup
#define CORB_CODE_Syrup

  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-stubs.c"
  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-common.c"

  #include "/home/corbinbs/masters_proj/CORBin/c_orb_output/Syrup-skels.c"

#endif

