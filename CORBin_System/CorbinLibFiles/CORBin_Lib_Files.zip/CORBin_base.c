/***************************CORBin-lib*********************************/
/* CORBin_base.c
 *
 * Some useful user-level C functions.
 * Declared and registered on the C side by cutil-CORBin.h
 */
#include <orb/orbit.h>
#include "CORBin_CosNaming.h"   /*******For Name Service Capability*****/
#include "CORBin_name.h"        /*******For Name Service Capability*****/
#include <string.h>

#include "CORBin_CosNaming-common.c"
#include "CORBin_CosNaming-stubs.c"
#include "CORBin_name.c"

CORBA_Environment ev;
CORBA_ORB orb;

void CORBin_exception_init()
{
    CORBA_exception_init(&ev);
}

void CORBin_orb_init(char * str)
{
    int argc=3;
    char * argv[3];

    argv[0] = (char *) malloc(strlen("./CORBinTest") + 1);
    argv[1] = (char *) malloc(strlen(str) +1 );
    argv[2] = (char *) malloc(strlen("-ORBIIOPIPv4=1") +1 );
	

    strcpy(argv[0], "./CORBinTest");
    strcpy(argv[1], str);
    strcpy(argv[2], "-ORBIIOPIPv4=1");

    orb = CORBA_ORB_init(&argc, argv, "orbit-local-orb",&ev); 

}

CORBA_Object CORBin_string_to_object(char * str) 
{
    CORBA_Object x;
    
    x = CORBA_ORB_string_to_object(orb, str, &ev);

    return x;
}

void CORBin_Object_release(CORBA_Object obj)
{
   CORBA_Object_release(obj, &ev);
}

CORBA_Object CORBin_Object_duplicate(CORBA_Object obj)
{
	return CORBA_Object_duplicate(obj, &ev);
}


void CORBin_ORB_run() 
{
   CORBA_ORB_run(orb, &ev);
}

void * CORBin_ORB_resolve_initial_references(char * ref_name)
{
   return CORBA_ORB_resolve_initial_references(orb, ref_name, &ev);
}

void CORBin_PortableServer_POAManager_activate(PortableServer_POAManager p)
{
   PortableServer_POAManager_activate(p, &ev);
}

PortableServer_POAManager 
CORBin_PortableServer_POA__get_the_POAManager(PortableServer_POA root_poa)
{
  return PortableServer_POA__get_the_POAManager(root_poa, &ev);
}

CosNaming_Name * CORBin_create_name(char * id)
{
  return create_name(id);
}

CORBA_Object CORBin_CosNaming_NamingContext_resolve(
					CosNaming_NamingContext name_srv,
					CosNaming_Name * obj_name)
{
    CORBA_Object x;

	x = CosNaming_NamingContext_resolve(name_srv, obj_name, &ev);

	return x;	
}

void CORBin_CosNaming_NamingContext_bind(
					CosNaming_NamingContext name_srv,
					CosNaming_Name * obj_name,
					CORBA_Object the_obj)
{
   CosNaming_NamingContext_bind(name_srv,obj_name, the_obj, &ev);
}


